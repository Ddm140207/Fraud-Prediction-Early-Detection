import numpy as np
import pandas as pd
import random
from faker import Faker
from datetime import datetime, timedelta

fake = Faker()

# CONFIGURACIÓN
N = 100001  # número de filas que querés generar
fraud_rate = 0.03  # 3% de fraudes

# FUNCIONES AUXILIARES

def random_date(start_year=2015, end_year=2025):
    start = datetime(start_year,1,1)
    end = datetime(end_year,12,31)
    return start + timedelta(days=random.randint(0, (end-start).days))

def generate_device_id():
    return "DEV-" + ''.join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", k=3))

def generate_city(country):
    if country == "Costa Rica":
        return random.choice(["San Jose", "Heredia", "Cartago", "Alajuela"])
    if country == "US":
        return random.choice(["San Francisco", "Austin", "Miami", "Seattle"])
    if country == "MX":
        return random.choice(["Guadalajara", "Monterrey", "CDMX"])
    return fake.city()

# GENERAR DATOS

data = []

countries = ["Costa Rica", "US", "MX", "Panama", "Colombia"]
genders = ["Male", "Female", "Other", "Unknown"]
employment_statuses = ["Employed", "Unemployed", "Self-employed", "Retired", "Student"]
marital_statuses = ["Single", "Married", "Divorced", "Widowed"]
occupations = ["IT", "Retail", "Finance", "Healthcare", "Logistics", "Freelancer"]
kyc_levels = ["none", "basic", "enhanced"]

for i in range(N):

    # --- Datos personales ---
    customer_id = f"CUST{i:05d}"
    account_id = f"ACC{i+10000}"

    signup = random_date()

    age = int(np.clip(np.random.normal(38, 12), 18, 85))
    gender = random.choice(genders)
    country = random.choice(countries)
    city = generate_city(country)

    account_age_days = (datetime.now() - signup).days

    employment = random.choice(employment_statuses)
    income = float(abs(np.random.lognormal(mean=10, sigma=0.5))) / 100  # ingreso aprox 8k–50k

    occupation = random.choice(occupations)
    marital = random.choice(marital_statuses)
    dependents = int(np.clip(np.random.normal(1, 1), 0, 6))

    credit_score = int(np.clip(np.random.normal(650 + (income/10000), 70), 300, 850))
    avg_balance = float(abs(np.random.normal(income * 0.4, income * 0.2)))

    # --- Comportamiento de uso ---
    last_login = fake.date_time_between(start_date="-5d", end_date="now")
    logins_30d = int(abs(np.random.normal(15, 10)))
    tx_30d = int(abs(np.random.normal(50, 30)))

    avg_tx_amt = abs(np.random.normal(40, 25))
    med_tx_amt = max(1, avg_tx_amt * random.uniform(0.5, 1))
    max_tx = avg_tx_amt * random.uniform(3, 80)
    min_tx = avg_tx_amt * random.uniform(0.01, 0.2)
    std_tx = abs(avg_tx_amt * random.uniform(0.3, 1.5))

    pct_large_tx = random.uniform(0, 0.4)
    failed_logins = int(np.random.poisson(1))

    device_change = random.choices([0,1], [0.9, 0.1])[0]
    ip_changes = int(abs(np.random.normal(2, 3)))

    domestic_foreign_ratio = random.uniform(0.8, 1.0)
    new_payees = int(abs(np.random.normal(1, 2)))

    billing_mismatch = random.choices([0,1], [0.97, 0.03])[0]
    shipping_mismatch = random.choices([0,1], [0.95, 0.05])[0]

    chargebacks = int(abs(np.random.poisson(0.3)))
    disputes = int(abs(np.random.poisson(0.5)))

    velocity_1h = int(abs(np.random.poisson(1)))
    night_ratio = random.uniform(0, 0.5)
    weekend_ratio = random.uniform(0, 0.5)
    risk_score = random.uniform(0, 1)

    avg_distance = abs(np.random.normal(10, 30))
    device_id = generate_device_id()

    vpn_flag = random.choices([0,1], [0.85, 0.15])[0]
    twofa = random.choice([0,1])
    email_rep = int(np.clip(np.random.normal(80, 15), 0, 100))
    phone_verified = random.choice([0,1])
    kyc = random.choice(kyc_levels)

    pwd_days = int(abs(np.random.normal(60, 90)))
    session_avg = abs(np.random.normal(300, 120))

    loan_flag = random.choice([0,1])
    loan_amt = float(abs(np.random.normal(5000, 8000))) if loan_flag == 1 else 0.0
    credit_util = random.uniform(0, 1)

    # FRAUDE
    fraud = 1 if random.random() < fraud_rate else 0

    # Reforzar comportamiento fraudulento
    if fraud == 1:
        ip_changes += random.randint(5,15)
        device_change = 1
        vpn_flag = 1
        pct_large_tx = random.uniform(0.5, 1)
        new_payees += random.randint(3,12)
        risk_score = random.uniform(0.7, 1)
        velocity_1h = random.randint(3,12)
        night_ratio = random.uniform(0.5, 1)
        weekend_ratio = random.uniform(0.5, 1)

    row = [
        customer_id, account_id, signup.date(), age, gender, country, city,
        account_age_days, employment, income, occupation, marital, dependents,
        credit_score, avg_balance, last_login, logins_30d, tx_30d, avg_tx_amt,
        med_tx_amt, max_tx, min_tx, std_tx, pct_large_tx, failed_logins,
        device_change, ip_changes, domestic_foreign_ratio, new_payees,
        billing_mismatch, shipping_mismatch, chargebacks, disputes,
        velocity_1h, night_ratio, weekend_ratio, risk_score, avg_distance,
        device_id, vpn_flag, twofa, email_rep, phone_verified, kyc,
        pwd_days, session_avg, loan_flag, loan_amt, credit_util, fraud
    ]

    data.append(row)

# Crear DataFrame y exportar a CSV

cols = [
    "customer_id","account_id","signup_date","age","gender","country","city",
    "account_age_days","employment_status","annual_income","occupation",
    "marital_status","num_dependents","credit_score","avg_monthly_balance",
    "last_login","num_logins_30d","num_transactions_30d","avg_tx_amount_30d",
    "median_tx_amount_30d","max_tx_amount_30d","min_tx_amount_30d",
    "std_tx_amount_30d","pct_large_tx_30d","num_failed_logins_30d",
    "device_change_flag","ip_change_count_30d","domestic_foreign_tx_ratio",
    "tx_to_new_payees_30d","billing_address_mismatch_flag",
    "shipping_address_mismatch_flag","num_chargebacks_lifetime",
    "num_disputes_12m","velocity_tx_1h","night_tx_ratio","weekend_tx_ratio",
    "merchant_category_risk_score","avg_tx_distance_km","frequent_device_id",
    "is_vpn_flag","two_factor_enabled","email_domain_reputation",
    "phone_verified","kyc_level","recent_password_change_days",
    "session_duration_avg_seconds","loan_active_flag",
    "loan_amount_outstanding","credit_utilization_ratio","is_fraud_label"
]

df = pd.DataFrame(data, columns=cols)
df.to_csv("synthetic_bank_fraud_dataset.csv", index=False)

print("CSV generado: synthetic_bank_fraud_dataset.csv")
df.head()
